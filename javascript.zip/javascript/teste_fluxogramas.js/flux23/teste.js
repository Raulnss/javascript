function aFunction() {
    var n1 = window.document.getElementById("a")
      n1 = Number(a.value)
      var r = (9*n1+160)/5
      re.innerHTML =("farenrait =  ")+" "+r
    }