function aFunction() {
    let n1 = window.document.getElementById("n")
      n1 = Number(n.value)
      let r = n1*n1
      re.innerHTML = r
}