function aFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("p")
      n1 = Number(n.value)
      n2 = Number(p.value)
      let r = (n1*n2)/2
      re.innerHTML =("area = ")+ r
}