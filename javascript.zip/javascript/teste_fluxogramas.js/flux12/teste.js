function aFunction() {
    let n1 = window.document.getElementById("a")
      n1 = Number(a.value)
      for (let i = 0; i <= 10; i++) {
        alert(n1*i)
      }
}