function aFunction() {
    var n1 = window.document.getElementById("a")
    var ope = window.document.getElementById("op")
    var n2 = window.document.getElementById("b")
      n1 = Number(a.value)
       var r = n1%2
      if (r==0) {
        re.innerHTML =("numero par")
      } else {
        re.innerHTML =("numero impar")
      }
    }