function aFunction() {
    var n1 = window.document.getElementById("a")
    var n2 = window.document.getElementById("b")
      n1 = Number(a.value)
      n2 = Number(b.value)
      var n3
      n3=n1
      n1=n2
      n2=n3
      re.innerHTML = n1+" "+n2
    }