function nomeFunction() {
    let n = window.document.getElementById("nome")
    let n1 = window.document.getElementById("sobr")
    n = (nome.value)
    n1 = (sobr.value)
    let r = n+" "+n1
    res.innerHTML = r
}