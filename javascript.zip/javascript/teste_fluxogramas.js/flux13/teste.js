function aFunction() {
    let n1 = window.document.getElementById("a")
    let n2 = window.document.getElementById("b")
      n1 = Number(a.value)
      n2 = Number(b.value)
      let d = n1 / n2
      let r = n1 % n2
      re.innerHTML =("divisao = ")+ d + ("resto = ")+r
}