function aFunction() {
    let n1 = window.document.getElementById("a")
      n1 = Number(a.value)
      let r = n1 * 5.20
      re.innerHTML =("voce tem = ")+ r
}