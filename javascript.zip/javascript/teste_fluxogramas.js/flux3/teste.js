function sFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("nn")
    n1 = Number(n.value)
    n2 = Number(nn.value)
    let r = n1 + n2
    re.innerHTML = r
    }
function suFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("nn")
    n1 = Number(n.value)
    n2 = Number(nn.value)
    let r = n1 - n2
    re.innerHTML = r   
    }
function mFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("nn")
    n1 = Number(n.value)
    n2 = Number(nn.value)
    let r = n1 * n2
    re.innerHTML = r  
    }
function dFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("nn")
    n1 = Number(n.value)
    n2 = Number(nn.value)
    let r = n1 / n2
    re.innerHTML = r 
    }
function rFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("nn")
    n1 = Number(n.value)
    n2 = Number(nn.value)
    let r = n1 % n2
    re.innerHTML = r
}