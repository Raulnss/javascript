function aFunction() {
    let n1 = window.document.getElementById("a")
     n1 = Number(a.value)
    var resp = n1+1
    var res = n1-1
    re.innerHTML = ("antessesor") +res+(" ")+("sucessor")+resp
}