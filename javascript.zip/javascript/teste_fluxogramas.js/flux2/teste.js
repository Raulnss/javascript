function nomeFunction() {
    let n1 = window.document.getElementById("n")
    let n2 = window.document.getElementById("d")
    n1 = (n.value)
    n2 = Number(d.value)
    let da = 2023-n2
    let r = n1+" você tem "+da+" anos de idade"
    re.innerHTML = r
}