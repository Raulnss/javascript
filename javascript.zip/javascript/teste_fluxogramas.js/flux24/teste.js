function aFunction() {
    var n1 = window.document.getElementById("a")
      n1 = (a.value)
      if (n1=="marrom") {
        re.innerHTML =("preço do marrom = R$15,00 ")
      } else if (n1=="verde") {
        re.innerHTML =("preço do verde = R$20,00 ")
      } else if (n1=="azul") {
        re.innerHTML =("preço do azul = R$40,00 ")
      } else if (n1=="vermelho") {
        re.innerHTML =("preço do vermelho = R$80,00 ")
      } else {
        re.innerHTML =("não esta no sistema")
      }
    }