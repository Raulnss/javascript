var n1;
var r = 0; 
function teste() {
    do {
        n1=Number(prompt("numero: "))
        r = r + n1
    } while (n1 != 0)
    re.innerHTML = r;
}