function aFunction() {
    for (let a = 1; a <= 10; a++) {
        for (let b = 1; b <= 10; b++) {
            resp=a*b
            window.document.write(resp+"-")
        }
    }
}